function show(){
	alert("successfully registered!!");
	window.location="index.html"
}